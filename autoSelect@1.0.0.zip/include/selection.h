#ifndef SELECTION_H
#define SELECTION_H

void selectorInit();
extern int autonSelection;


#endif
